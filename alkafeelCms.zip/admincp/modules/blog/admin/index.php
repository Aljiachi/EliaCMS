<style type="text/css">
.control_table{
	border-collapse:collapse;
	}
.control_table td{
	text-align:center;
	background:#FCFCFC;
	border:solid 1px #D8D8D8;
	padding:5px;
	}
.control_table td:hover{
	background:#EBEBEB;
	}
.control_table td img{	
	}
.control_table td a{
	text-decoration:none;
	font-size:14px;
	font-weight:bold;
	color:#2D2D2D;	
	}
</style>
<table style="margin-left:auto; margin-right:auto; position:relative;" dir="ltr" border="0" cellspacing="0" class="control_table" cellpadding="5">
  <tr>
    <td width="128"><img src="modules/blog/images/comments.png" /></td>
    <td width="128"><img src="modules/blog/images/control.png" /></td>
    <td width="128"><img src="modules/blog/images/add.png" /></td>
    <td width="128"><img src="modules/blog/images/control.png" /></td>
    <td width="128"><img src="modules/blog/images/add.png" /></td>
  </tr>
  <tr>
    <td><a href="modules.php?action=admin&module=<?php print ModuleID; ?>&page=comments">التحكم بالتعليقات</a></td>
    <td><a href="modules.php?action=admin&module=<?php print ModuleID; ?>&page=sections">التحكم بالتصانيف</a></td>
    <td><a href="modules.php?action=admin&module=<?php print ModuleID; ?>&page=addsection">إضافة تصنيف</a></td>
    <td><a href="modules.php?action=admin&module=<?php print ModuleID; ?>&page=topics">التحكم بالمقالات</a></td>
    <td><a href="modules.php?action=admin&module=<?php print ModuleID; ?>&page=addtopic">إضافة مقال</a></td>
  </tr>
</table>
