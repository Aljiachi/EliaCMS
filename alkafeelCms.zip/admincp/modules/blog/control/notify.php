<?php

	/*
		if(mysql_num_rows(mysql_query("select id from blog_module_comments where active = 0")) !== 0){
			
		print '<div><a href="modules.php?action=admin&module='.$this->NotifyModuleId.'&page=comments&&active=0">يوجد ' . mysql_num_rows(mysql_query("select id from blog_module_comments where active = 0")) . ' تعليق بإنتظار التفعيل</a></div>';
		
	}
	*/
?>