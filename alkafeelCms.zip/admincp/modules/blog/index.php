<div id="module_links">

	<a target="_new">
    <div><img src="modules/blog/add.png" /></div>
    إضافة مقال
    </a>
    
</div>