﻿
	<a href="modules.php?action=admin&module=<?php print ModuleID; ?>&page=addnews" class="newContent">إضافة خبر جديد</a>
<?php
	

?>