<?php
	
	if(!defined("script_run")){exit;}
	
	_print('تاريخ اليوم : ' . date("d/F/Y h:i:s" , time() ) );

?>