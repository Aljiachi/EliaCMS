    	<div id="block" style="width:50%; margin-left:auto;margin-right:auto;">
    	<div id="menu_title">رسالة إدارية</div>
        <div id="menu_body"><div class="system_blocked_message"></div></div>
        </div>
        