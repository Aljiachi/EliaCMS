<div id="block">
    	<div id="menu_title">من نحن</div>
        <div id="menu_body">أللهم صــــــل علــــــــــــى مــحمد وآل محمد 
كيف الحال </div>
</div>        